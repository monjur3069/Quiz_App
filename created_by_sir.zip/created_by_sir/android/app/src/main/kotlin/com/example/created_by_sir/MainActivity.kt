package com.example.created_by_sir

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
